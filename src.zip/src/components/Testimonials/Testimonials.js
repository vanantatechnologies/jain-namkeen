import React from "react";
import "./Testimonials.scss";

const Testimonials = () => {
    return (
        <header className="header">

        </header>
    );
};

export default Testimonials;
